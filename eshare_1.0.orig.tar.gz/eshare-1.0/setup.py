from setuptools import setup

setup(
    name='eshare',
    version='1.0',
    author='GNINGHAYE Malcolmx Hassler',
    author_email='guemandeuhassler96@gmail.com',
    description='Secure FTP server using SSL Certificates',
    scripts=['e_share.py'],
    data_files=[('/etc/systemd/system', ['eshare.service']), ('/etc/eshare', ['eshare.conf'])],
    install_requires=['pyftplib','configparser'],
    classifiers=[
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python",
        "Programming Language :: Python :: 3",
        "Operating System :: POSIX :: Linux",
    ],
)
